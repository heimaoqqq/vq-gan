"""
Generate Samples from Trained LDM Baseline
===========================================
从训练好的LDM Baseline生成样本
"""

import os
import sys
from pathlib import Path
import argparse

import torch
from torchvision import utils
import numpy as np

# 添加当前目录到路径，支持直接运行
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from models import VQVAE
from configs import LDMBaselineConfig

# 导入扩散模型
import importlib.util
spec = importlib.util.spec_from_file_location(
    "cfg_module", 
    os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                 "denoising_diffusion_pytorch/classifier_free_guidance.py")
)
cfg_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cfg_module)
Unet = cfg_module.Unet
GaussianDiffusion = cfg_module.GaussianDiffusion


def load_models(vqgan_path, ldm_path, device='cuda'):
    """加载VQ-GAN和LDM模型"""
    
    # 加载VQ-GAN
    print(f"Loading VQ-GAN from {vqgan_path}...")
    vqgan_checkpoint = torch.load(vqgan_path, map_location='cpu')
    vqgan_config = vqgan_checkpoint['config']
    
    vqvae = VQVAE(
        in_channels=vqgan_config['in_channels'],
        out_channels=vqgan_config['out_channels'],
        ch=vqgan_config['ch'],
        ch_mult=tuple(vqgan_config['ch_mult']),
        num_res_blocks=vqgan_config['num_res_blocks'],
        attn_resolutions=tuple(vqgan_config['attn_resolutions']),
        dropout=vqgan_config['dropout'],
        z_channels=vqgan_config['z_channels'],
        num_embeddings=vqgan_config['num_embeddings'],
        embedding_dim=vqgan_config['embedding_dim'],
        commitment_cost=vqgan_config['commitment_cost'],
    )
    vqvae.load_state_dict(vqgan_checkpoint['vqvae'])
    vqvae.eval()
    vqvae.to(device)
    print("✓ VQ-GAN loaded")
    
    # 加载LDM
    print(f"Loading LDM from {ldm_path}...")
    ldm_checkpoint = torch.load(ldm_path, map_location='cpu')
    ldm_config_dict = ldm_checkpoint['config']
    
    # 重建LDM配置
    ldm_config = LDMBaselineConfig()
    for key, value in ldm_config_dict.items():
        if hasattr(ldm_config, key):
            setattr(ldm_config, key, value)
    
    # 创建UNet
    model = Unet(
        dim=ldm_config.dim,
        dim_mults=ldm_config.dim_mults,
        num_classes=ldm_config.num_classes,
        cond_drop_prob=ldm_config.cond_drop_prob,
        channels=ldm_config.latent_channels,
        attn_dim_head=ldm_config.attn_dim_head,
        attn_heads=ldm_config.attn_heads,
        learned_variance=False
    )
    
    # 创建扩散模型
    diffusion = GaussianDiffusion(
        model,
        image_size=ldm_config.latent_size,
        timesteps=ldm_config.timesteps,
        sampling_timesteps=ldm_config.sampling_timesteps,
        objective=ldm_config.objective,
        beta_schedule=ldm_config.beta_schedule,
        min_snr_loss_weight=False,
        auto_normalize=ldm_config.auto_normalize
    )
    
    # 加载权重
    diffusion.load_state_dict(ldm_checkpoint['model'])
    diffusion.eval()
    diffusion.to(device)
    print("✓ LDM loaded")
    
    return vqvae, diffusion, ldm_config


def generate_samples(
    vqvae, 
    diffusion, 
    user_ids,
    device='cuda',
    cond_scale=1.0,  # Baseline不使用CFG，固定为1.0
    rescaled_phi=0.0,
    batch_size=8,
):
    """生成样本"""
    
    all_images = []
    
    # 分批生成
    for i in range(0, len(user_ids), batch_size):
        batch_user_ids = user_ids[i:i+batch_size]
        batch_user_ids = torch.tensor(batch_user_ids, device=device)
        
        print(f"Generating batch {i//batch_size + 1} (users {batch_user_ids.tolist()})...")
        
        with torch.no_grad():
            # 生成潜在表示
            sampled_latents = diffusion.sample(
                classes=batch_user_ids,
                cond_scale=cond_scale,
                rescaled_phi=rescaled_phi
            )
            
            # 解码
            sampled_images = vqvae.decode_latents(sampled_latents)
            
            all_images.append(sampled_images.cpu())
    
    # 合并所有批次
    all_images = torch.cat(all_images, dim=0)
    
    return all_images


def main():
    parser = argparse.ArgumentParser(description='Generate samples from LDM Baseline')
    parser.add_argument('--vqgan_path', type=str, required=True, 
                       help='Path to VQ-GAN checkpoint')
    parser.add_argument('--ldm_path', type=str, required=True,
                       help='Path to LDM checkpoint')
    parser.add_argument('--output_dir', type=str, default='./generated_samples',
                       help='Output directory')
    parser.add_argument('--num_samples_per_user', type=int, default=10,
                       help='Number of samples to generate per user')
    parser.add_argument('--users', type=str, default='all',
                       help='User IDs to generate (e.g., "0,1,2" or "all")')
    parser.add_argument('--device', type=str, default='cuda',
                       help='Device to use')
    parser.add_argument('--batch_size', type=int, default=8,
                       help='Batch size for generation')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    
    args = parser.parse_args()
    
    # 设置随机种子
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    
    # 创建输出目录
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True, parents=True)
    
    # 加载模型
    vqvae, diffusion, config = load_models(
        args.vqgan_path,
        args.ldm_path,
        args.device
    )
    
    # 确定要生成的用户
    if args.users == 'all':
        user_ids = list(range(config.num_classes))
    else:
        user_ids = [int(x) for x in args.users.split(',')]
    
    print(f"\n{'='*60}")
    print(f"Generating {args.num_samples_per_user} samples for {len(user_ids)} users...")
    print(f"Total samples: {len(user_ids) * args.num_samples_per_user}")
    print(f"{'='*60}\n")
    
    # 生成样本
    for user_id in user_ids:
        print(f"\nGenerating for User {user_id}...")
        
        # 为当前用户生成多个样本
        user_ids_repeated = [user_id] * args.num_samples_per_user
        
        images = generate_samples(
            vqvae,
            diffusion,
            user_ids_repeated,
            device=args.device,
            cond_scale=1.0,  # Baseline不使用CFG
            rescaled_phi=0.0,
            batch_size=args.batch_size,
        )
        
        # 保存每个用户的样本网格
        grid_path = output_dir / f'user_{user_id:02d}_grid.png'
        utils.save_image(
            images,
            str(grid_path),
            nrow=min(args.num_samples_per_user, 10)
        )
        print(f"✓ Saved grid: {grid_path}")
        
        # 保存单独的图像
        user_dir = output_dir / f'user_{user_id:02d}'
        user_dir.mkdir(exist_ok=True)
        
        for i, img in enumerate(images):
            img_path = user_dir / f'sample_{i:03d}.png'
            utils.save_image(img, str(img_path))
        
        print(f"✓ Saved {len(images)} individual images to {user_dir}")
    
    print(f"\n{'='*60}")
    print(f"✓ Generation complete!")
    print(f"Output directory: {output_dir}")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()

