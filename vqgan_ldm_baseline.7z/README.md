# VQ-GAN + LDM Baseline

严格论文复现，用于对比实验。

## 训练流程

### 1. 创建数据划分（必须先执行）

```bash
python vqgan_ldm_baseline/create_data_split.py \
    --data_path /kaggle/input/organized-gait-dataset/Normal_line \
    --num_users 31 \
    --images_per_user_train 50 \
    --output ./vqgan_ldm_baseline/data_split.json
```

**划分策略**：分层等间隔采样
- 从每个用户的150张图像中均匀采样50张作为训练集
- 剩余100张作为测试集
- 训练集和测试集严格分离，无重叠

### 2. 训练VQ-GAN（阶段一）

```bash
python vqgan_ldm_baseline/train_vqgan.py
```

**预计时间**：3-5天（RTX 3090）

### 3. 训练LDM（阶段二）

```bash
python vqgan_ldm_baseline/train_ldm_baseline.py
```

**预计时间**：2-3天（RTX 3090）

### 4. 生成样本

```bash
python vqgan_ldm_baseline/generate_baseline.py \
    --vqgan_path ./vqgan_ldm_baseline/results/vqgan/vqgan-25.pt \
    --ldm_path ./vqgan_ldm_baseline/results/ldm_baseline/model-33.pt \
    --num_samples_per_user 10
```

## 数据严格分离

- ✅ 训练集和测试集严格分离
- ✅ VQ-GAN和LDM使用完全相同的训练集
- ✅ 分层等间隔采样确保训练集多样性
- ✅ 所有划分信息保存在`data_split.json`便于追溯

## 关键配置

- Codebook: 512 codes × 256 dim
- 下采样: 8× (256→32)
- 无EMA、无CFG、无对比学习、无Min-SNR
- 梯度裁剪: max_norm=1.0

