"""
LDM Baseline Training Script
=============================
阶段二：在VQ-GAN潜在空间训练基础扩散模型

论文Baseline：条件LDM（仅Cross-Attention）
不包含：CFG, EMA, 对比学习, Min-SNR等优化
"""

import os
import sys
from pathlib import Path
import argparse
from tqdm import tqdm
import math

import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
from PIL import Image
import numpy as np

# 添加当前目录到路径，支持直接运行
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

from models import VQVAE
from configs import LDMBaselineConfig
from accelerate import Accelerator

# 导入您现有的扩散模型（复用架构）
import importlib.util
spec = importlib.util.spec_from_file_location(
    "cfg_module", 
    os.path.join(os.path.dirname(os.path.dirname(__file__)), 
                 "denoising_diffusion_pytorch/classifier_free_guidance.py")
)
cfg_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cfg_module)
Unet = cfg_module.Unet
GaussianDiffusion = cfg_module.GaussianDiffusion


# ============================================================
# 数据集
# ============================================================
class LatentDataset(Dataset):
    """潜在空间数据集（从VQ-GAN编码）"""
    
    def __init__(
        self, 
        vqvae: VQVAE,
        data_path: str, 
        latents_cache_folder: str,
        split_file: str = './data_split.json'
    ):
        super().__init__()
        self.vqvae = vqvae
        self.data_path = Path(data_path)
        self.latents_cache_folder = Path(latents_cache_folder)
        
        # ✅ 从统一的划分文件读取训练集
        import json
        split_path = Path(split_file)
        
        if not split_path.exists():
            raise FileNotFoundError(
                f"数据划分文件不存在: {split_file}\n"
                f"请先运行: python vqgan_ldm_baseline/create_data_split.py"
            )
        
        with open(split_path, 'r', encoding='utf-8') as f:
            split_info = json.load(f)
        
        print(f"✓ 读取数据划分: {split_file}")
        print(f"  划分方法: {split_info['sampling_method']}")
        
        # 收集训练集图像路径和标签
        self.samples = []
        for user_key, user_info in split_info['users'].items():
            label = user_info['label']  # 0-30
            for rel_path in user_info['train_images']:
                img_path = self.data_path / rel_path
                if img_path.exists():
                    self.samples.append((img_path, label))
                else:
                    print(f"⚠️  图像不存在: {img_path}")
        
        print(f"LDM训练集: {len(self.samples)} 张图像")
        print(f"  (来自 {split_info['statistics']['total_users']} 用户)")
        
        # 图像预处理
        self.transform = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(256),
            transforms.ToTensor()
        ])
    
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        
        # 尝试从缓存加载
        cache_filename = f"user_{label:02d}_{img_path.stem}.pt"
        cache_path = self.latents_cache_folder / cache_filename
        
        if cache_path.exists():
            latent = torch.load(cache_path, map_location='cpu', weights_only=True)
        else:
            # 从原始图像编码
            img = Image.open(img_path).convert('RGB')
            img = self.transform(img)
            
            with torch.no_grad():
                img_batch = img.unsqueeze(0).to(next(self.vqvae.parameters()).device)
                latent = self.vqvae.encode_images(img_batch)  # [1, C, H, W]
                latent = latent.squeeze(0).cpu()  # [C, H, W]
            
            # 保存缓存
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            torch.save(latent, cache_path)
        
        return latent, label


# ============================================================
# 训练器
# ============================================================
class LDMBaselineTrainer:
    """LDM Baseline训练器（严格论文方法，无任何优化）"""
    
    def __init__(self, config: LDMBaselineConfig):
        self.config = config
        
        # 打印配置
        config.print_config_summary()
        
        # 初始化Accelerator
        self.accelerator = Accelerator(
            split_batches=True,
            mixed_precision='fp16' if config.amp else 'no'
        )
        
        # 设置随机种子
        torch.manual_seed(config.seed)
        np.random.seed(config.seed)
        
        # 加载VQ-GAN
        print("Loading VQ-GAN...")
        checkpoint = torch.load(config.vqgan_path, map_location='cpu')
        
        # 重建VQ-VAE配置
        vqgan_config = checkpoint['config']
        self.vqvae = VQVAE(
            in_channels=vqgan_config['in_channels'],
            out_channels=vqgan_config['out_channels'],
            ch=vqgan_config['ch'],
            ch_mult=tuple(vqgan_config['ch_mult']),
            num_res_blocks=vqgan_config['num_res_blocks'],
            attn_resolutions=tuple(vqgan_config['attn_resolutions']),
            dropout=vqgan_config['dropout'],
            z_channels=vqgan_config['z_channels'],
            num_embeddings=vqgan_config['num_embeddings'],
            embedding_dim=vqgan_config['embedding_dim'],
            commitment_cost=vqgan_config['commitment_cost'],
        )
        self.vqvae.load_state_dict(checkpoint['vqvae'])
        self.vqvae.eval()
        self.vqvae.requires_grad_(False)
        self.vqvae = self.vqvae.to(self.accelerator.device)
        print(f"VQ-GAN loaded from {config.vqgan_path}")
        
        # 创建数据集
        print("Creating dataset...")
        train_ds = LatentDataset(
            self.vqvae,
            config.data_path,
            config.latents_cache_folder,
            split_file='./data_split.json'
        )
        
        self.train_dl = DataLoader(
            train_ds,
            batch_size=config.batch_size,
            shuffle=True,
            num_workers=config.num_workers,
            pin_memory=True
        )
        
        # 创建UNet模型（与优化版架构一致）
        print("Creating Unet model...")
        self.model = Unet(
            dim=config.dim,
            dim_mults=config.dim_mults,
            num_classes=config.num_classes,
            cond_drop_prob=config.cond_drop_prob,  # 0.0: 不使用CFG
            channels=config.latent_channels,
            attn_dim_head=config.attn_dim_head,
            attn_heads=config.attn_heads,
            learned_variance=False
        )
        
        num_params = sum(p.numel() for p in self.model.parameters())
        print(f"Model parameters: {num_params/1e6:.2f}M")
        
        # 创建扩散模型
        print("Creating diffusion model...")
        self.diffusion = GaussianDiffusion(
            self.model,
            image_size=config.latent_size,
            timesteps=config.timesteps,
            sampling_timesteps=config.sampling_timesteps,
            objective=config.objective,
            beta_schedule=config.beta_schedule,
            min_snr_loss_weight=False,  # ❌ 不使用Min-SNR
            auto_normalize=config.auto_normalize
        )
        
        # 创建优化器（标准配置，无weight decay）
        self.opt = torch.optim.Adam(
            self.diffusion.parameters(),
            lr=config.learning_rate,
            betas=config.adam_betas,
            weight_decay=config.weight_decay
        )
        
        # 使用Accelerator准备
        self.diffusion, self.opt, self.train_dl = self.accelerator.prepare(
            self.diffusion, self.opt, self.train_dl
        )
        
        # ❌ 不使用EMA（论文未提）
        
        # 创建结果文件夹
        self.results_folder = Path(config.results_folder)
        if self.accelerator.is_main_process:
            self.results_folder.mkdir(exist_ok=True, parents=True)
        
        self.step = 0
        
        print("\n" + "="*60)
        print("✓ 初始化完成，开始训练...")
        print("="*60 + "\n")
    
    def train(self):
        """训练循环"""
        config = self.config
        
        # 创建无限循环的dataloader
        def cycle(dl):
            while True:
                for data in dl:
                    yield data
        
        dl = cycle(self.train_dl)
        
        with tqdm(
            initial=self.step,
            total=config.train_steps,
            disable=not self.accelerator.is_main_process
        ) as pbar:
            while self.step < config.train_steps:
                self.diffusion.train()
                total_loss = 0.
                
                # 梯度累积
                for grad_accum_idx in range(config.gradient_accumulate_every):
                    latents, labels = next(dl)
                    latents = latents.to(self.accelerator.device)
                    labels = labels.to(self.accelerator.device)
                    
                    with self.accelerator.autocast():
                        # 计算扩散损失（标准，无对比学习）
                        loss = self.diffusion(latents, classes=labels)
                        
                        total_loss += loss.item()
                        
                        # 为梯度累积缩放损失
                        loss = loss / config.gradient_accumulate_every
                    
                    self.accelerator.backward(loss)
                
                # 梯度裁剪（保守值：防止训练不稳定）
                self.accelerator.clip_grad_norm_(self.diffusion.parameters(), max_norm=1.0)
                
                # 优化器步进
                self.opt.step()
                self.opt.zero_grad()
                
                self.accelerator.wait_for_everyone()
                
                # 更新进度
                pbar.set_description(f'loss: {total_loss:.4f}')
                
                self.step += 1
                
                # ❌ 不使用EMA更新（论文未提）
                
                # 定期保存和采样
                if self.accelerator.is_main_process:
                    if self.step % config.save_and_sample_every == 0:
                        self.save_and_sample(self.step // config.save_and_sample_every)
                
                pbar.update(1)
        
        print('LDM Baseline训练完成!')
    
    def save_and_sample(self, milestone):
        """保存检查点并生成样本"""
        self.diffusion.eval()
        
        print(f"\n{'='*60}")
        print(f"Checkpoint {milestone} (步数: {self.step})")
        print(f"{'='*60}")
        
        # 生成样本（每个用户1张）
        try:
            with torch.no_grad():
                num_samples = min(self.config.num_samples, self.config.num_users)
                user_ids = torch.arange(num_samples, device=self.accelerator.device)
                
                # ❌ 不使用CFG，直接采样
                # 标准采样（cond_scale=1.0表示无CFG）
                sampled_latents = self.diffusion.sample(
                    classes=user_ids,
                    cond_scale=1.0,  # 无CFG
                    rescaled_phi=0.0  # 无CFG++
                )
                
                # VQ-GAN解码
                sampled_images = self.vqvae.decode_latents(sampled_latents)
                
                # 保存图像网格
                save_path = self.results_folder / f'sample-{milestone}.png'
                utils.save_image(
                    sampled_images,
                    str(save_path),
                    nrow=int(math.sqrt(num_samples))
                )
                print(f"✓ 样本已保存: {save_path}")
                
                # 简单质量检查
                img_min = sampled_images.min().item()
                img_max = sampled_images.max().item()
                img_mean = sampled_images.mean().item()
                
                print(f"  图像统计: min={img_min:.3f}, max={img_max:.3f}, mean={img_mean:.3f}")
                
        except Exception as e:
            print(f"  ✗ 生成样本失败: {e}")
            import traceback
            traceback.print_exc()
        
        # 保存检查点
        if self.accelerator.is_local_main_process:
            try:
                data = {
                    'step': self.step,
                    'model': self.accelerator.get_state_dict(self.diffusion),
                    'opt': self.opt.state_dict(),
                    'config': self.config.__dict__,
                }
                save_path = self.results_folder / f'model-{milestone}.pt'
                torch.save(data, str(save_path))
                print(f"✓ 检查点已保存: {save_path}")
                
                # 同时保存最新检查点
                latest_path = self.results_folder / 'model_latest.pt'
                torch.save(data, str(latest_path))
                print(f"✓ 最新检查点: {latest_path}")
                
            except Exception as e:
                print(f"  ✗ 保存检查点失败: {e}")
        
        print(f"{'='*60}\n")
    
    def load(self, milestone):
        """加载检查点"""
        load_path = self.results_folder / f'model-{milestone}.pt'
        data = torch.load(str(load_path), map_location=self.accelerator.device)
        
        model = self.accelerator.unwrap_model(self.diffusion)
        model.load_state_dict(data['model'])
        
        self.step = data['step']
        self.opt.load_state_dict(data['opt'])
        
        print(f"Loaded checkpoint from {load_path}, step {self.step}")


# ============================================================
# 主函数
# ============================================================
def main():
    parser = argparse.ArgumentParser(description='Train LDM Baseline')
    parser.add_argument('--resume', type=int, default=None, help='Resume from milestone')
    args = parser.parse_args()
    
    # 创建配置
    config = LDMBaselineConfig()
    
    # 创建训练器
    trainer = LDMBaselineTrainer(config)
    
    # 恢复训练（如果指定）
    if args.resume is not None:
        trainer.load(args.resume)
    
    # 开始训练
    trainer.train()


if __name__ == '__main__':
    main()

