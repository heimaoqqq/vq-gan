"""
Configuration files for VQ-GAN + LDM Baseline
"""

from .vqgan_config import VQGANConfig
from .ldm_baseline_config import LDMBaselineConfig

__all__ = ['VQGANConfig', 'LDMBaselineConfig']

