"""
LDM Baseline Configuration
===========================
阶段二：基础LDM训练配置

严格遵循论文，不使用任何优化技术
"""

from dataclasses import dataclass
from typing import Tuple


@dataclass
class LDMBaselineConfig:
    """
    LDM Baseline训练配置
    
    仅包含论文明确提到的内容，不包含任何优化
    """
    
    # ============================================================
    # 路径配置
    # ============================================================
    vqgan_path: str = './results/vqgan/vqgan_best.pt'
    data_path: str = '/kaggle/input/organized-gait-dataset/Normal_line'  # Kaggle路径
    results_folder: str = './results/ldm_baseline'
    latents_cache_folder: str = './latents_cache'
    
    # ============================================================
    # 数据配置
    # ============================================================
    num_users: int = 31
    images_per_user_train: int = 50
    total_train_images: int = 31 * 50  # 1550张
    image_size: int = 256
    latent_size: int = 32  # 8倍下采样
    latent_channels: int = 256  # VQ-GAN的潜在通道数
    
    # ============================================================
    # 扩散模型配置（标准DDPM）
    # ============================================================
    timesteps: int = 1000  # 标准DDPM
    sampling_timesteps: int = 250  # DDIM采样步数
    objective: str = 'pred_noise'  # 最常用
    beta_schedule: str = 'linear'  # 最传统（保守）
    
    # ============================================================
    # UNet配置（与优化版保持一致，便于公平对比）
    # ============================================================
    dim: int = 96
    dim_mults: Tuple[int] = (1, 2, 4, 4)
    num_classes: int = 31
    channels: int = 256  # VQ-GAN的潜在通道数
    attn_dim_head: int = 64
    attn_heads: int = 8
    
    # ============================================================
    # 条件生成（论文提到）
    # ============================================================
    # Cross-Attention条件注入（论文明确提到）
    use_cross_attention: bool = True
    
    # ❌ 不使用CFG（论文未提）
    cond_drop_prob: float = 0.0  # CFG需要>0，这里=0表示不用
    use_cfg: bool = False
    cond_scale: float = 1.0  # 不用CFG，设为1.0
    rescaled_phi: float = 0.0  # 不用CFG++
    
    # ============================================================
    # 训练配置（标准配置，无优化）
    # ============================================================
    batch_size: int = 8  # 保守：小batch
    gradient_accumulate_every: int = 4  # 有效batch=32（为了对齐优化版）
    learning_rate: float = 1e-4  # 标准lr（不用优化的4e-5）
    adam_betas: Tuple[float] = (0.9, 0.999)  # 标准Adam
    weight_decay: float = 0.0  # ❌ 不使用（论文未提）
    
    train_steps: int = 20000  # 约400 epochs（防止小数据集过拟合）
    max_grad_norm: float = 1.0  # 梯度裁剪（保守值，防止训练不稳定）
    
    # ============================================================
    # 不使用的优化（论文未提）
    # ============================================================
    use_ema: bool = False  # ❌ 论文未提
    ema_decay: float = None
    ema_update_every: int = None
    
    use_contrastive_loss: bool = False  # ❌ 论文未提
    contrastive_weight: float = 0.0
    
    use_min_snr: bool = False  # ❌ 论文未提
    min_snr_loss_weight: bool = False
    min_snr_gamma: int = None
    
    auto_normalize: bool = False  # VQ潜在空间不需要归一化
    
    # ============================================================
    # 监控与保存
    # ============================================================
    save_and_sample_every: int = 1000  # 每1000步保存（约21 epochs），总计20个checkpoint
    num_samples: int = 16
    
    # ============================================================
    # 其他
    # ============================================================
    amp: bool = False  # 混合精度（保守：不使用）
    num_workers: int = 0
    seed: int = 42
    
    def __post_init__(self):
        """验证配置"""
        assert self.latent_size == self.image_size // 8, "潜在空间大小应为图像的1/8"
        assert self.cond_drop_prob == 0.0, "Baseline不使用CFG，cond_drop_prob必须为0"
        assert not self.use_cfg, "Baseline不使用CFG"
        assert not self.use_ema, "Baseline不使用EMA"
        assert not self.use_contrastive_loss, "Baseline不使用对比学习"
        assert not self.use_min_snr, "Baseline不使用Min-SNR"
    
    def print_config_summary(self):
        """打印配置摘要"""
        print("\n" + "="*60)
        print("LDM Baseline训练配置（论文方法）")
        print("="*60)
        
        print(f"\n数据集:")
        print(f"  用户数: {self.num_users}")
        print(f"  每用户图像: {self.images_per_user_train}")
        print(f"  总训练图像: {self.total_train_images}")
        
        print(f"\n潜在空间:")
        print(f"  大小: {self.latent_size}×{self.latent_size}")
        print(f"  通道: {self.latent_channels}")
        
        print(f"\n扩散模型:")
        print(f"  Timesteps: {self.timesteps} (训练) / {self.sampling_timesteps} (采样)")
        print(f"  Objective: {self.objective}")
        print(f"  Schedule: {self.beta_schedule}")
        
        print(f"\nUNet:")
        print(f"  Dim: {self.dim}")
        print(f"  Layers: {self.dim_mults}")
        print(f"  Attention: {self.attn_heads} heads × {self.attn_dim_head} dim")
        
        print(f"\n条件生成:")
        print(f"  ✅ Cross-Attention（论文提到）")
        print(f"  ❌ CFG（论文未提）")
        
        print(f"\n训练:")
        print(f"  Batch: {self.batch_size} × {self.gradient_accumulate_every} = {self.batch_size * self.gradient_accumulate_every}")
        print(f"  LR: {self.learning_rate}")
        print(f"  Steps: {self.train_steps:,}")
        print(f"  约等于: {self.train_steps / (self.total_train_images / (self.batch_size * self.gradient_accumulate_every)):.1f} epochs")
        
        print(f"\n不使用的优化（论文未提）:")
        print(f"  ❌ EMA")
        print(f"  ❌ CFG / CFG++")
        print(f"  ❌ 对比学习")
        print(f"  ❌ Min-SNR")
        print(f"  ❌ Weight decay")
        print(f"  ❌ 梯度裁剪")
        
        print("="*60 + "\n")

